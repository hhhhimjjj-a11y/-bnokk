package com.bunookak.app

import android.os.Bundle
import com.bunookak.app.databinding.ActivitySettingsBinding
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val current = prefs.getString("BASE_URL", getString(R.string.default_base_url))
        binding.editBaseUrl.setText(current)

        binding.btnSave.setOnClickListener {
            val url = binding.editBaseUrl.text.toString().trim()
            prefs.edit().putString("BASE_URL", url.ifBlank { "asset://local" }).apply()
            finish()
        }
    }
}
